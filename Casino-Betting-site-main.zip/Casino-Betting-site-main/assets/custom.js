const init = () => {
    if (document.getElementsByClassName("tab-box")[0])
        document.getElementsByClassName("tab-box")[0].innerHTML =
            '<ul data-v-7c156064="">' +
            '<li data-v-7c156064="" class="active">' +
            '<img data-v-7c156064="" src="./assets/ic_tab_home.png" alt="">' +
            '<span data-v-7c156064="">' + 'Lobby' +
            '</span>' +
            '</li>' +
            '<li data-v-7c156064="" class="">' +
            '<img data-v-7c156064="" src="./assets/004b898e26974be1be4cf90a642594e6.webp" alt="">' +
            '<span data-v-7c156064="">' + 'Originals' +
            '</span>' +
            '</li>' +
            '<li data-v-7c156064="" class="">' +
            '<img data-v-7c156064=""  src="./assets/9e691fbf990f4472921612791c7b16e1.webp" alt="">' +
            '<span  data-v-7c156064="">' + 'Slots' +
            '</span>' +
            '</li>' +
            '<li data-v-7c156064="" class="">' +
            '<img data-v-7c156064=""  src="./assets/8dbb65defebc48ff9095d5c9800701a0.webp" alt="">' +
            '<span data-v-7c156064="">' + 'Live Casino' + '</span>' +
            '</li>' +
            '<li data-v-7c156064="" class="">' +
            '<img data-v-7c156064="" src="./assets/8dbb65defebc48ff9095d5c9800701a0.webp" alt="">' +
            '<span data-v-7c156064="">' + 'New Game' + '</span>' +
            '</li>' +
            '</ul>';
    if (document.getElementsByClassName("my-bet-con")[0])
        document.getElementsByClassName("my-bet-con")[0].innerHTML =
            `<div data-v-f4ae7b86="" class="my-bet-con">
<div data-v-f4ae7b86="" class="my-bet-wrapper" style="display: none;">
    <div data-v-f4ae7b86="" class="no-data">
        <div data-v-336994dc="" data-v-f4ae7b86="" class="no-data-wrapper"
            style="background-color: rgb(25, 32, 46);"><img data-v-336994dc="" src="./assets/no-data.33361e18.webp"
                alt=""><span data-v-336994dc="">No record yet </span></div>
    </div>
</div>
<div data-v-f4ae7b86="" class="all-bet-wrapper">
    <ul data-v-f4ae7b86="" class="item-wrapper">
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">Cleocatra</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:40</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">19.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">2.63x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="win">
                        <li data-v-4c1c52d7="" class="">31. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">showHand</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:39</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">33.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">0.00x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="lose">
                        <li data-v-4c1c52d7="" class="">-33. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">redEnvelope</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:37</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">60.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">0.00x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="lose">
                        <li data-v-4c1c52d7="" class="">-60. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/9a933bc301ab4f1b87f3526040f26372.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">Ethernet Card</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:32</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">94.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">0.00x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="lose">
                        <li data-v-4c1c52d7="" class="">-94. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">888 Gold</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:31</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">13.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">2.69x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="win">
                        <li data-v-4c1c52d7="" class="">22. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">The Tiger Warrior</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:28</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">64.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">2.93x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="win">
                        <li data-v-4c1c52d7="" class="">124. </li>
                        <li data-v-4c1c52d7="" class="">0000000 </li>
                        <li data-v-4c1c52d7="" class="mask">... </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">Wild Spells</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:25</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">64.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">1.68x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="win">
                        <li data-v-4c1c52d7="" class="">44. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/8dbb65defebc48ff9095d5c9800701a0.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">Super Sic Bo</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:23</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">89.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">0.00x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="lose">
                        <li data-v-4c1c52d7="" class="">-89. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">Tree of Riches</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:21</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">91.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">2.16x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="win">
                        <li data-v-4c1c52d7="" class="">106. </li>
                        <li data-v-4c1c52d7="" class="">0000000 </li>
                        <li data-v-4c1c52d7="" class="mask">... </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="game-name">
                <div data-v-f4ae7b86="" class="icon"><img data-v-f4ae7b86=""
                        src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/9a933bc301ab4f1b87f3526040f26372.webp"
                        alt=""></div>
                <div data-v-f4ae7b86="" class="desc"><span data-v-f4ae7b86="">Lucky Ethernet</span></div>
            </div>
            <div data-v-f4ae7b86="" class="create-time">2023-05-03 00:59:19</div>
            <div data-v-f4ae7b86="" class="bet-money"><span data-v-f4ae7b86="">82.00000000</span><img
                    data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt=""></div>
            <div data-v-f4ae7b86="" class="multiple">0.00x</div>
            <div data-v-f4ae7b86="" class="profit">
                <div data-v-4c1c52d7="" data-v-f4ae7b86="" class="format-money-wrapper">
                    <ul data-v-4c1c52d7="" class="lose">
                        <li data-v-4c1c52d7="" class="">-82. </li>
                        <li data-v-4c1c52d7="" class="">00000000 </li>
                    </ul>
                </div><img data-v-f4ae7b86=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/46421bebc1bf4bf88438e8e6ed65d0d6.png"
                    alt="">
            </div>
        </li>
    </ul>
</div>
<div data-v-f4ae7b86="" class="ranking-wrapper" style="display: none;">
    <ul data-v-f4ae7b86="" class="item-wrapper">
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAnCAYAAAAcsCj6AAAAAXNSR0IArs4c6QAABDVJREFUWEftl1FoHFUUhv9zZ3Y3m9KY6ZJEA602VlQKpX0oRVI3EyKiaMW0pKjBChEp+qAPQpVd1FCSYKEPgrRQBUWFtjZVEbRCBGeWiqBYtn1QrEL70lrTZLNp2m7a7cw9cjfZze5mZ3c2wT55X2bmnnPPd8+Zc87cIRQNPnQoMJtKjQB4DkBrsayO+8sADocjkRjt3n2rfB0VT2SGh98F0Rt1GPdWZd7XGI+/6QlkgGZHRi4BaKsBPDovf6aG3ng4FruLAC7WK3jIfX3a7MaNN0Cklxhi/ir3TNSbu0jZpa4sRCI3XyYvrGV2wqdPN9DoqOsN3LTpBoASoAuYaoEG2JWA5fIi4044mawfWO5Rref/gaVJU+EdStd9XIVJaNp3ld5huXzZIQXwz7yRO3Ng5kfVVRKNzc+XyP0DBwfFbDCYARDyrC9SVcXnwapqaS3mnr3Ub36TTK7Y6VUWalVmeHgniD4DEMxbYceBnJiATKXAMzPgbBaQEhACFAqBmpogIhGIlhaQpi3AmV9tjMff9+w0eUFmaKiXhDgis9mQc+4c5MWLgOsqj7wbi/JS0yBWr0ago4NZ14dXxGJvVVpQ0cqV/v4Dcnz8FThOdVC5RWaQrmfhOP3Ntn3cF3C6u3sfA3u83fEhYUWmIcOy3q4a0rRp7gfR6z5M+lXZa1jWOxV76VRX18skxEG/lnzrSbnLSCRUIuZG7h1ejkbvCwhxBkRhX4aKS6FaMs0Zmwkxr2+07QsFYNo0v8x/fqoCmSHb2uBu7wOCAeijx0CX/vazx08Ny3ohB7zW07PhlpRJ1UQ8VzKDQyG4T26D+7SCBXNlEIjtgfjrrB9gVjLfG7HtC1QrUbihAc7AS5CbtwDhxgXj9QHBUsZXJRIjNG2avzPRg17b5NZWZA98OFf8aqir6ih1AgH8YljWFkp3dytLnuHk1jZkD34AOvsH9KOH4fTvAt+ztm4gATfTzM00ZZpMVTKNdR1YuRKUSuUadXb/e+C76weq4Fxz3Q3KQ892vyjMrrssoAs8cluBAnjstgFVe9WAhxRQ5jtOzYJaTkiZ+Xom06KA477/I5YHPG/Ydocq/OMg2lHTu/kaXHKWSvmRkUi8SOlodDs07Yv/GsjMD6+y7R9J/VNcmZz8jYH7a0KXGlLmXw3b3rzwtfDr5RKAKjvV0bI5kfi+AFQ306Z5jIn6qnopJdxtT4GNCCAI4sS3EJMTtQLzsWFZA3mlwiFqeutWQ+r6T0T0QC0LvuXMZ5qDwU4aG7u+CKgmpjo71yAQOEFE630b9VBk4GfXcXpbTp5UP7mFseiYONPTE3Fc9xMiemKpUGL+PHP16kD7qVPqJF8yKp5LBwHxmmk+D6K9ANbUAf6TmONeZ9KSpKlklNetC6Xb23dAiGeJKMpAU/EO1WeGmNNE9AOAI3cwf0227VTb4L+Coz6whC+86QAAAABJRU5ErkJggg=="
                    alt=""></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">hhh***@qq.com</span></div>
            <div data-v-f4ae7b86=""> 23188.16 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAnCAYAAAAcsCj6AAAAAXNSR0IArs4c6QAABRJJREFUWEftV1tsFFUY/v4ze02xabvcuq3EoqgE5EGQAltukRCNT0BoVGQ3YgiiiRrwgqCCRImoECJKYmIsW4JgxQsvagQNNW2hBiQQRIMRhJauxULl1u5l5vzmzNK6u52dHcRHz8OeOfNfvvnvZwkZiw++7+7Wr6wD8DBAQzNpzp/5HICPSl2DVtKEJalcOcp8cWH/hjdA9IJz5TaczOvLJi9fYQdI3Qc2xhgYVgBw5zX6g3Z8BHSWTlpWDoAz+fot5IYGrXtEexyAK8vNjM/VmQhzzF3I6WpnKRrNPYeeIauXnqn0UW2tcV2AhsQMJaAJ7LMCzKXfMGCuRYXO/wMWThqJ+9Oxw1eWSZNDv2GXAvjjmpLhaheQs9UuIb659j6L7hyQ14juA8U9IHjz15dyCJ9KlxZVAebZkp0IiT2n9xfV1n5iXRZK6vz+jbWCsI0BT58WljrklRiMnk5w/C+wrkpVmj4mzQ/ylUArGgZRVA4SWj+4ZPnU4MnPbrbrNCatq2XjHE3DDplKePULv8C4eAosDRBldcEsPcwMEi5oJVVwB0YzC/frgUnLXrYy3VJL5xcL3jMun30CMmW2GMeLGdBcSTJSC8ojLbscAcbqa9Yz8LxjEEtGZjBeC0aaX7F1aUf9lLcBsfzGwP6RJvDa8nDzaste2r51ylIhxJb/CqxPj4QMV4ZbtvWdzQC11VWP0jT3EQB+K0BmCVFyO7Shd4O8pYCmgXu6oLd9C+7tsk0ogC95hT4m8Ehru9k41E9HNPQZiMzxM8Dn3jJ4Jr4ELXCXmknZ2Sl1JI9uhv77lyASds6pD4abIiZgZ7R6nAHX4XwSomwMfNM2mYOPjQQ4fh7kH2yWgfpeVRLxxifBF3/LC8jgJCf0WysXt7ZToUQRZWPhHrsYqZ+3QnYdARspUNEw+Ke/m3YvGKmTu5E6usW+hJhXBSPN66ijvuY4gNF5P89TDE5dAWW6kxnucUvhHpmOgh5rQbJ1tdl9bNYPwXBTNXVEQ6qN2HLmKlFJ5J2wEq7KmWnAtr1IHnqzgIVIJGR7CXVEazidOs4X+QLwzaoDaek+n/jxLRhtewsq6DWMccql1u0+n7jLD9/UTRDFt5gcsvcc4nseBVgvCCilMcs5oGrQgyrgrV4LcdPNZrJw6iriTc+BL50sCJZmMO5zBKhi5grWwDN+BUhTk4sgr55F4sBq8OUzjhq8cqOW6JmsAFU1280eaJUz4B3/Yr9i/Wwjkoc3AEbCoWWKjVlyagh11Ic67f5HkH9IOkGE2/yu1IntSB6vu97EVoinguGmkQpwF0DzLD/VrLfH4R45Nx2B88eQaH0VyJjs6cwxgORFW9cyyw8rIi2PKcC5AH1qBaiuF/57P4AorkqTzavMQO8bF44h3vh01hVjgD7mqcFIcxNxA7RYPPQTQHcMZJLw3bcTwhewjZWyPP79MzaAfDAYbr5HKUlPi3xWMsM1an5/gedDlb1/Qj/9tWVc1a0DgmdXLGze0w+oHmL1NQ0MzL+OtHPEyoy6ikjToj7m/oCc3l5T6ta5BUR3OtLkgInBRzRcDg0PH706ANB0bTQ0AoCapmMc6LNlYaDVQ71zhiw8FMtkHJBy7dGJAUGeKIAH/i0ogT/m3vii4JJDPbk6LDvMmjUQS6pCC5loLQBltdN1gliuyncnzUoaK42/vnObt6hk+DxmPETE08BUnN0EzcLsBvg7EO8or/Tsppn7bMfG31vdWJEhxqiaAAAAAElFTkSuQmCC"
                    alt=""></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">382***@gmail.com976282cb72e54df6a861f4bcd6b5eee8</span>
            </div>
            <div data-v-f4ae7b86=""> 8240.00 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAnCAYAAAAcsCj6AAAAAXNSR0IArs4c6QAABTBJREFUWEftl2tsFFUUx39nZrfblgIltFhpQB4iCBE/+CAN0BZDQDQmIkIUFWOrIWg0EI0aiUIIEEkQjAiGkJYgiWgFCR98oSHdgG0ooIKRRI0WU17lJQJtt+3OHHOHbbu73dm26EdPsjt77z33/5/zvHeFONl8WIPNUVaLMh8YEr/Wh9/nVPgoO8AbC++W9uR9Ej+xvlbfFnitD+C+qgprlhTJ62kIVd6t5QxwUw+EH8fWH+tBr3FxETeDaLxep4VVVWqfGkZEIJAEtDs2nu09bUq8p0M4Np+4HptUiBY2kDlvnji+hKeHESGJ0FVKzQZLqE5F2G29Cz069EYIu1mUbGF3izso/ydU2yeGs2Ix/NInhonr/zqGwlkPQynwnsKM2HhvbJy43lvC5apWbi3NCCG/+jI1pFAfWx8ZG/upt37XQL9P/crC7FpXq/MEtgtkdKaaC2evQmMTXG6BVgdc9cqErADkZsKQHCjIAdvq4lZ4aUmRbEh+m4TW5pHW6GxL2NEaJfTLBThxGRwXpJtmHLhCwIKRg2BsPhq0WLW4SN5MZXpKmAW7dOOpKzwf7YEoGVAVgjZtUZcnqstkZ68ISyp1jcCrfoHpzbyaUCsrw+XyVlqXllboWoSXewPaGx2FFeEyWZayl5ZU6iKBTb0B6ouOuiwIPyvbO/Z4MSzeqmNEOWoSLxWYiU0ooNyZ7zB8oOtl5+VW4afzFvWXbS9j/UThimQwofpJOXm9jIGSCv1MhOvHTwoZnOXywcwIIduEpgvdEqXmZIB1dRm0uf6sCh+Gy+Rpj3DqFp1o2fwgEFdFiawF/Vy2zGrBZO3FFvFI87O7ztWv/rDZ9H3I11KFtojD6IPPyUkprtC1Vg+Jkp/tUlTo8G19gGvthlApn9jGw7dFPSc1tcP8Pdk91erScLmslpIKPS7C7ekSwcTQc0ec1/KyXCoeaPGsNY3h0d1ZCe5OUaN14XKZZAgdEX93+iXR+DyHNdMiuCqc+Ft4cW9WQmvrtk9pxSJXSis0Pg98DTUJMzrX9UBvGegyb1w7/U2bV1hZk8HhM4G0LjXAre1MlNLKDoelr64RAx02zox47jNWGTl+waLyWJDfLtk9khl9x2V6HwhdNs5o8U4K8zFucV04ftFi/aEMLrb4JnmnJQ7c32vCgKXkZal3KgzNcXloTJQ78h2P+FyT8MLeTKLpa5FghCJD6HY0gL60LEeVDdMjjMg1Kay8Uxdif0PylbYL0TilpZl8KanURunhf4SJcvJ5aNz6yqQIxcPM+8KWH4N8/nvQv8Up9eFyGWWydCfCHD9NA1xUGOXIWZs2R7xuYuYGZbq8PyNC/wxT+sqq2hB1p9NaWBkuk3Ip3qqPWMqudITLJkcYl+dy9JzFpRYhJ0MpKnQJ2V5VcKFZWPR1+hiiTK0ulwMyt0rt89f4GRibitRRWD4lwl0F112XKMr5ZosVBzJouGr7uxMOh8vkHq9bma90Vpr4DRvgct+IdsYPdj0Xmibe2CwcOm2z788ATqwuUzKabLGYEX5GvukkND9KKrVKYK7faxpiY22HmFimOwc79BS2hsukrGPc2Y6nbNJBdiY1AuP6Uh496B69FGDysQXS1I3QTEzerMODQb4AJvwHpAeddmbvXyjmT26ndDum792mg7OjbEN48EZJXfikqZ2yIwulORkj9b1guVqlw3nK3LoEhveWWJVfXWHpfp87aULSpAK99T0NDe3PHHF5HKFYYEC8npdDwl/iss+BHfYo9lRPE3MN8JV/ANUuMlPvqOB5AAAAAElFTkSuQmCC"
                    alt=""></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">123***@qq.com</span></div>
            <div data-v-f4ae7b86=""> 1553.65 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><span data-v-f4ae7b86="">4</span></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">zhu***@gmail.com</span></div>
            <div data-v-f4ae7b86=""> 605.87 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><span data-v-f4ae7b86="">5</span></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">123***@qq.com</span></div>
            <div data-v-f4ae7b86=""> 469.03 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><span data-v-f4ae7b86="">6</span></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">123***@qq.com</span></div>
            <div data-v-f4ae7b86=""> 121.12 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><span data-v-f4ae7b86="">7</span></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">mra***@gmail.com</span></div>
            <div data-v-f4ae7b86=""> 18.00 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
        <li data-v-f4ae7b86="">
            <div data-v-f4ae7b86="" class="ranking-img"><span data-v-f4ae7b86="">8</span></div>
            <div data-v-f4ae7b86=""><span data-v-f4ae7b86="">ww2***@gmail.com</span></div>
            <div data-v-f4ae7b86=""> 6.00 <img data-v-f4ae7b86=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGKADAAQAAAABAAAAGAAAAADiNXWtAAACrUlEQVRIDbVWS2hTQRQ9dxq0FhMUyaYIFmpKwUVFTDfiTpASUASXbsR9QRcVXCQvWbrQvQhuCi7FT9woiCIIjdW6ECx+cCF1U2gwglTNjGcmeZ80mZcKOvDeu3PvmXPnc+feJ0hrb4L9+KlPE1KCkUkIxh3cYA1iPlKuY4e6i5ngi49GBhpeBeP4baqAOU/7yEBMrGwDcgsZqeBIsBarO1K/g0ZwCkYv0pzdCh7Sb0HUORSDe0mcSnbwMpjnrO9Q97fkloZjONZxxKzxCuzMLcCYXqcxdnuSiOaWnQlX0nHg9ly/68xiezxDUC1k1LQ9k85s3YEO2RbBKvJql3tEng9xkO0ECdcCG4qb+jMH+KNFhNEhVS77hiNeqR1CW2e5nXPQpuxx1sZONZHpxnkaeZPkx0n+KSI6XH7r5Ea5EOn6hRHLnaG+1G9LaIzcxizJjREsV87SMhZZtToG8Ez9rZRxNxTGDwHWnfFDNQstC7zB3Bo5wIgbHUJOiEyq6Pp7XegTzlQIvmG2WkSxNo287IXIVe+Q0MDUImhUWlz+7lA38CtyDXv2XUFhfrPH3ig/5OLnenTJjsh3RUBf/khinGzMJTTXv2Kp8gJL5cew98Y2ox64r+9F7ozLigZTPgy38D5tT5xd7FmpX8jnNlxfIZd6xsy4NorqfFKWiac4WrvuCJOv90EOTXMhqRog15XL5wBTrqcZlcdKMIXXwUSEWK6exIZ+xrM7GOn6hbblVp1iwXzua0Zf5oVZ5dV/FEHaeoHyTNQfKJCThWj7yU7sZZEfXa5Rzj4t625JdrYS2WLhUu3A6TBieNzGjHUfP7nlsFzd6hYDbSUSuZjqxOM7UjtyciSqWlxwQtR/LZnWifVuiwXkJnv+6Aon5DDE2jGJmYfm/hWEFvv9B78tfwCN6e9wQsnvBAAAAABJRU5ErkJggg=="
                    alt=""></div>
        </li>
    </ul>
</div>
</div>`;

    // document.getElementsByClassName("game")[0].innerHTML =
    //     `
    // <li data-v-719dc418="" class="hide-casino"><span data-v-719dc418="" class="el-tooltip item" aria-describedby="el-tooltip-4114"
    //         tabindex="0"><img data-v-719dc418=""
    //             src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"></span>
    // </li>
    // <li data-v-719dc418="" class="hide-casino"><span data-v-719dc418="" class="el-tooltip item" aria-describedby="el-tooltip-3481"
    //         tabindex="0"><img data-v-719dc418=""
    //             src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/9e691fbf990f4472921612791c7b16e1.webp"></span>
    // </li>
    // <li data-v-719dc418="" class="hide-casino"><span data-v-719dc418="" class="el-tooltip item" aria-describedby="el-tooltip-0"
    //         tabindex="0"><img data-v-719dc418=""
    //             src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/9a933bc301ab4f1b87f3526040f26372.webp"></span>
    // </li>
    // <li data-v-719dc418="" class="hide-casino"><span data-v-719dc418="" class="el-tooltip item" aria-describedby="el-tooltip-1031"
    //         tabindex="0"><img data-v-719dc418=""
    //             src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/8dbb65defebc48ff9095d5c9800701a0.webp"></span>
    // </li>
    // <li data-v-719dc418="" class="hide-casino"><span data-v-719dc418="" class="el-tooltip item" aria-describedby="el-tooltip-9151"
    //         tabindex="0"><img data-v-719dc418=""
    //             src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/8dbb65defebc48ff9095d5c9800701a0.webp"></span>
    // </li>
    // <li data-v-719dc418="" class="hide-sport" style="display: none;">
    //     <div data-v-719dc418="">
    //         <ul data-v-719dc418="">
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-2275" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon1"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-6015" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon2"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-5033" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon3"></i></span></li>
    //         </ul>
    //     </div>
    //     <div data-v-719dc418="">
    //         <ul data-v-719dc418="">
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-1262" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon4"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-8369" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon5"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-4116" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon6"></i></span></li>
    //         </ul>
    //     </div>
    //     <div data-v-719dc418="">
    //         <ul data-v-719dc418="">
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-5457" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon5"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-9983" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon5"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-3403" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon9"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-9591" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon10"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-4680" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon11"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-6732" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon12"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-2800" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon14"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-7624" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon15"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-6758" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon16"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-4830" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon17"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-2711" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon18"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-1498" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon17"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-7093" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon5"></i></span></li>
    //             <li data-v-719dc418=""><span data-v-719dc418="" class="el-tooltip item"
    //                     aria-describedby="el-tooltip-7718" tabindex="0"><i data-v-719dc418=""
    //                         class="iconfont icon-icon22"></i></span></li>
    //         </ul>
    //     </div>
    // </li>`;
    if (document.querySelector(".list-wrapper .list-item"))
        document.querySelector(".list-wrapper .list-item").innerHTML =
            `<h1 data-v-719dc418="">Game Category</h1>
        <ul data-v-719dc418="" class="casinoCategory">
            <li data-v-719dc418="" class=""><img data-v-719dc418=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/004b898e26974be1be4cf90a642594e6.webp"
                    alt=""><span data-v-719dc418="">Originals</span></li>
            <li data-v-719dc418="" class=""><img data-v-719dc418=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/9e691fbf990f4472921612791c7b16e1.webp"
                    alt=""><span data-v-719dc418="">Slots</span></li>
            <li data-v-719dc418="" class=""><img data-v-719dc418=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/9a933bc301ab4f1b87f3526040f26372.webp"
                    alt=""><span data-v-719dc418="">Hash Game</span></li>
            <li data-v-719dc418="" class=""><img data-v-719dc418=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/8dbb65defebc48ff9095d5c9800701a0.webp"
                    alt=""><span data-v-719dc418="">Live Casino</span></li>
            <li data-v-719dc418="" class=""><img data-v-719dc418=""
                    src="https://5823242400382459.oss-cn-hongkong.aliyuncs.com/8dbb65defebc48ff9095d5c9800701a0.webp"
                    alt=""><span data-v-719dc418="">New Game</span></li>
        </ul>
        <div data-v-719dc418="" class="sportCategory" style="display: none;">
            <ul data-v-719dc418="">
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon1"></i><span
                        data-v-719dc418="">Popular events</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon2"></i><span
                        data-v-719dc418="">Rolling Ball</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon3"></i><span data-v-719dc418="">The
                        game is about to start</span></li>
            </ul>
        </div>
        <div data-v-719dc418="" class="sportCategory" style="display: none;">
            <ul data-v-719dc418="">
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon4"></i><span data-v-719dc418="">Live
                        match</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon5"></i><span data-v-719dc418="">2022
                        World Cup</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon6"></i><span data-v-719dc418="">s12
                        League of Legends World Finals</span></li>
            </ul>
        </div>
        <div data-v-719dc418="" class="sportCategory" style="display: none;">
            <ul data-v-719dc418="">
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon5"></i><span
                        data-v-719dc418="">England Premier League</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon5"></i><span
                        data-v-719dc418="">football</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon9"></i><span
                        data-v-719dc418="">basketball</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon10"></i><span
                        data-v-719dc418="">eSports</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon11"></i><span
                        data-v-719dc418="">tennis</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon12"></i><span
                        data-v-719dc418="">Snooker</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon14"></i><span
                        data-v-719dc418="">Badminton</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon15"></i><span data-v-719dc418="">table
                        tennis</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon16"></i><span
                        data-v-719dc418="">baseball</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon17"></i><span
                        data-v-719dc418="">volleyball</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon18"></i><span
                        data-v-719dc418="">handball</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon17"></i><span data-v-719dc418="">beach
                        volleyball</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon5"></i><span
                        data-v-719dc418="">American football</span></li>
                <li data-v-719dc418=""><i data-v-719dc418="" class="iconfont icon-icon22"></i><span
                        data-v-719dc418="">Entertainment</span></li>
            </ul>
        </div>`;

    if (document.getElementsByClassName("game")[0]) {
        document.getElementsByClassName("game")[0].insertBefore(document.getElementsByClassName("hide-casino")[0].children[4], document.getElementsByClassName("game")[0].firstChild);
        document.getElementsByClassName("game")[0].insertBefore(document.getElementsByClassName("hide-casino")[0].children[3], document.getElementsByClassName("game")[0].firstChild);
        document.getElementsByClassName("game")[0].insertBefore(document.getElementsByClassName("hide-casino")[0].children[2], document.getElementsByClassName("game")[0].firstChild);
        document.getElementsByClassName("game")[0].insertBefore(document.getElementsByClassName("hide-casino")[0].children[1], document.getElementsByClassName("game")[0].firstChild);
        document.getElementsByClassName("game")[0].insertBefore(document.getElementsByClassName("hide-casino")[0].children[0], document.getElementsByClassName("game")[0].firstChild);
    }


    if (document.getElementsByClassName("lobby-wrapper")[0])
        document.getElementsByClassName("lobby-wrapper")[0].insertBefore(document.getElementsByClassName("game-box")[0], document.getElementsByClassName("lobby-wrapper")[0].firstChild);

    if (document.getElementsByClassName("top")[0])
        document.getElementsByClassName("top")[0].insertBefore(document.getElementsByClassName("logo")[0], document.getElementsByClassName("top")[0].firstChild);

    if (document.querySelector(".banner-box h1"))
        document.querySelector(".banner-box h1").innerHTML = "Welcome Bonus";

    if (document.getElementsByClassName("cate-wrapper")[0]) {
        document.getElementsByClassName("cate-wrapper")[0].children[0].addEventListener("click", clickCasinoList);
        document.getElementsByClassName("cate-wrapper")[0].children[1].addEventListener("click", clickSportList);
        let casinoClass = document.getElementsByClassName("cate-wrapper")[0].children[0].classList.value;
        if (casinoClass == "active") clickCasinoList();
        else clickSportList();
    }

    if (document.getElementsByClassName("home-wrapper")[0])
        document.getElementsByClassName("home-wrapper")[0].appendChild(document.getElementsByClassName("menu-wrapper")[0])

}

function clickCasinoList() {
    for (let i = 0; i < 5; i++) {
        document.getElementsByClassName("hide-casino-item")[i].style.display = "block";
        if (i < 3)
            document.getElementsByClassName("sportCategory")[i].style.display = "none";
    }
    document.getElementsByClassName("casinoCategory")[0].style.display = "block";
}

function clickSportList() {
    for (let i = 0; i < 5; i++) {
        document.getElementsByClassName("hide-casino-item")[i].style.display = "none";
        if (i < 3)
            document.getElementsByClassName("sportCategory")[i].style.display = "block";
    }
    document.getElementsByClassName("casinoCategory")[0].style.display = "none";

}

setTimeout(() => {
    init();
}, 3000);


function clickMenu() {
    isDisplay = document.getElementsByClassName("menu-box")[0].style.display;
    if (isDisplay == 'none')
        document.getElementsByClassName("menu-box")[0].style.display = 'flex';
    else
        document.getElementsByClassName("menu-box")[0].style.display = 'none';
}